﻿namespace News.Services;

public enum NewsScope
{
    Headlines,
    Local,
    Global
}
