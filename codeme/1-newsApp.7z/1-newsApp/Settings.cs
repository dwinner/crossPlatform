﻿namespace News;

internal static class Settings
{
    public static string NewsApiKey => "<Your APIKEY here>";

}
