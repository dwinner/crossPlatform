namespace News.Views;

public partial class ArticleItem : ContentView
{
	public ArticleItem()
	{
		InitializeComponent();
	}
}