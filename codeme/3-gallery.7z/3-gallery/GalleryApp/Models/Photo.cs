﻿namespace GalleryApp.Models;

public class Photo
{
    public string Filename { get; set; }
    public byte[] Bytes { get; set; }
}
