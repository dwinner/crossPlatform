﻿
namespace GalleryApp.Services;

internal static class Messages
{
    public const string FavoritesAddedMessage = nameof(FavoritesAddedMessage);
}
