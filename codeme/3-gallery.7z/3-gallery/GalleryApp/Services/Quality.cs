﻿namespace GalleryApp.Services;

public enum Quality
{
    Low, High
}

