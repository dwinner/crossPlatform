namespace MeTracker.Services;

public interface ILocationTrackingService
{
    void StartTracking();
}
