﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace MeTracker.ViewModels;

public partial class ViewModel: ObservableObject
{
}
