﻿using System;
using CommunityToolkit.Mvvm.ComponentModel;

namespace Weather.ViewModels;

public abstract partial class ViewModel : ObservableObject
{
}

