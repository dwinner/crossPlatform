﻿using System;

namespace Weather.Views;

public interface IMainView
{
}

