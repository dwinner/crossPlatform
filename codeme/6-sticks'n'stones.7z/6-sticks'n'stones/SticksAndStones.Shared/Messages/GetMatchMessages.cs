﻿using SticksAndStones.Models;

namespace SticksAndStones.Messages;

public record struct GetMatchResponse(Match Match);
