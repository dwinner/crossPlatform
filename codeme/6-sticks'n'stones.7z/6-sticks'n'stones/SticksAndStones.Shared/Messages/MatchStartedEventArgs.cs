﻿using SticksAndStones.Models;

namespace SticksAndStones.Messages;

public record struct MatchStartedEventArgs(Match Match);

