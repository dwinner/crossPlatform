﻿namespace SticksAndStones.Models;

public enum ChallengeResponse
{
    None,
    Accepted,
    Declined,
    TimeOut
}
