﻿namespace SticksAndStones.Models;

public class ConnectionInfo
{
    public string Url { get; set; }
    public string? AccessToken { get; set; }
}